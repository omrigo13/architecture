#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  char debug_mode;
  char file_name[128];
  int unit_size;
  unsigned char mem_buf[10000];
  size_t mem_count;
  char display_mode; //added for Toggle Display Mode
  /*
   .
   .
   Any additional fields you deem necessary
  */
} state;

void debugFlag(state* s)
{
  /* Toggle debug mode means turn the debug flag on or off */
  s->debug_mode = 1 - s->debug_mode;
  if(s->debug_mode)
    printf("Debug flag now on\n");
  else
    printf("Debug flag now off\n");
}

void setFile(state* s)
{
  /* queries the user for a file name, and store it in file_name */
  printf("please enter a file name: ");
  fgets(s->file_name, 100, stdin);
  strtok(s->file_name, "\n");
  if(s->debug_mode)
    fprintf(stderr, "Debug: file name set to: %s\n\n", s->file_name);
}

void setUnitSize(state* s)
{  
  /* option sets the size variable */  
  char size[3];
  printf("please enter a unit size (1, 2 or 4): ");
  fgets(size, 3, stdin);
  if (strncmp(size, "1", 1) == 0 || strncmp(size, "2", 1) == 0 || strncmp(size, "4", 1) == 0)
  {
    sscanf(size, "%d", &(s->unit_size));
    if(s->debug_mode)
      fprintf(stderr, "Debug: set size to: %d\n\n", s->unit_size);   
  }
  else
    printf("the size arguments is illigal: %s", size); 
}

void quit(state* s)
{
  /* is a function that prints "quitting" (in debug mode), and calls exit(0) to quit the program */
  if(s->debug_mode)
    fprintf(stderr, "quitting\n\n");
  free(s);
  exit(0);
}

struct fun_desc {
  char *name;
  void (*fun)(state*);
};

void read_units_to_memory(state* s)
{
  FILE* file;
  char buffer[10000];
  int location = -1, bytesLength = -1;
  if(s->file_name == NULL)
  {
    printf("file name is null");
    quit(s);
  }
  if(!(file = fopen(s->file_name, "r")))
  {
    printf("failed to open file\n");
    quit(s);
  }
  else 
  {
    printf("Please enter <location> <length>\n");
    fgets(buffer, 10000, stdin);
    sscanf(buffer, "%x %d", &location, &bytesLength);
    if(s->debug_mode)
      fprintf(stderr, "Debug: file name: %s, location: %#x, length: %d\n\n", s->file_name, location, bytesLength);
    fseek(file, location, SEEK_SET);
    fread(s->mem_buf, s->unit_size, bytesLength, file);
    fclose(file);
    printf("Loaded %d units into memory\n", bytesLength);
  }
}

void displayFlag(state* s)
{
  s->display_mode = 1 - s->display_mode;
  if(s->display_mode)
    printf("Display flag now on, hexadecimal representation\n");
  else
    printf("Display flag now off, decimal representation\n");
}

char* hexFormat(int unit) 
{
  static char* formats[] = {"%04hhx\n", "%04hx\n", "No such unit", "%04x\n"};
  return formats[unit-1];
}

char* decFormat(int unit) 
{
  static char* formats[] = {"%hhd\n", "%hd\n", "No such unit", "%d\n"};
  return formats[unit-1];
}

void print_units(FILE* output, char* buffer, int count, int unit_size, char dispMode)
{
  char* end = buffer + unit_size*count;
  int i = 0;
  while (buffer < end) 
  {
    int var = *((int*)(buffer));
    if(dispMode)
      fprintf(output, hexFormat(unit_size), var);
    else
      fprintf(output, decFormat(unit_size), var);
    i++;
    buffer += unit_size;
  }
}

void memoryDisplay(state* s)
{
  char buffer[10000];
  int u = -1, addr = -1;
  if(!s->display_mode)
  {
    printf("Decimal\n=======\n");
    fgets(buffer, 10000, stdin);
    sscanf(buffer, "%d", &u);
    fgets(buffer, 10000, stdin);
    sscanf(buffer, "%x", &addr);
    print_units(stdout,(addr ? (char*)addr : (char*)(s->mem_buf)), u, s->unit_size, s->display_mode);
  }
  else
  {
    printf("Hexadecimal\n===========\n");
    fgets(buffer, 10000, stdin);
    sscanf(buffer, "%d", &u);
    fgets(buffer, 10000, stdin);
    sscanf(buffer, "%x", &addr);
    print_units(stdout,(addr ? (char*)addr : (char*)(s->mem_buf)), u, s->unit_size, s->display_mode);
  }
  if(s->debug_mode)
    fprintf(stderr, "Debug: address: %#x, units: %d\n\n", addr, u);
}

void write_units(state* s)
{
  FILE* file;
  char buffer[10000];
  int size = 0, src = 0, targetLoc = 0, len = 0;
  if(!(file = fopen(s->file_name, "r+")))
  {
    printf("failed to open file\n");
    quit(s);
  }
  else
  {
    printf("Please enter <source-address> <target-location> <length>\n");
    fgets(buffer, 10000, stdin);
    sscanf(buffer, "%x %x %d", &src, &targetLoc, &len);
    if(s->debug_mode)
      fprintf(stderr, "Debug: source address: %#x, target location: %#x, length: %d\n\n", src, targetLoc, len);
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    if(targetLoc > size)
      printf("invalid location input");
    else
    {
      fseek(file, targetLoc, SEEK_SET);
      fwrite((src ? (void*)src : (void*)s->mem_buf), len, s->unit_size, file);
      fclose(file);
    }
  }
}

void memoryModify(state* s)
{
  FILE* file;
  char buffer[10000];
  int size = 0, loc = 0, val = 0;
  if(!(file = fopen(s->file_name, "r+")))
  {
    printf("failed to open file\n");
    quit(s);
  }
  else
  {
    printf("Please enter <location> <val>\n");
    fgets(buffer, 10000, stdin);
    sscanf(buffer, "%x %x", &loc, &val);
    if(s->debug_mode)
      fprintf(stderr, "Debug: location: %#x, value: %x\n\n", loc, val);
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    if(loc > size)
      printf("invalid location input");
    else
    {
      fseek(file, loc, SEEK_SET);
      fwrite((void*)&val, s->unit_size, 1, file);
      fclose(file);
      int temp = val;
      for(int i = loc; i < (loc + s->unit_size); i++)
      {
        s->mem_buf[i] = temp%256;
        temp = temp/256;
      }
    }
  }
  
}

int main(int argc, char **argv){
  struct fun_desc menu[] = { { "Toggle Debug Mode", debugFlag }, { "Set File Name", setFile }, { "Set Unit Size", setUnitSize }, 
  { "Load Into Memory", read_units_to_memory }, { "Toggle Display Mode", displayFlag }, { "Memory Display", memoryDisplay },
  {"Save Into File", write_units}, {"Memory Modify", memoryModify}, { "Quit", quit }, { NULL, NULL } };
  int choice = -1, index = 0;
  char input[100];
  state* s = calloc(1, sizeof(state));
  s->unit_size = 1;
  while((menu+index)->name != NULL)
    index++;
  index -= 1;
  while(1)
  {
    if(s->debug_mode)
      fprintf(stderr, "Debug: unit size: %d, file name: %s, mem count: %u\n\n", s->unit_size, s->file_name, s->mem_count);    
    printf("Choose action:\n");
    for(int i = 0; (menu + i)->name != NULL; i++) 
      printf("%d-%s\n", i, (menu + i)->name);
    printf("option: ");
    fgets(input, 100, stdin);
    if(strcmp(input, "\n") == 0)
      continue;
    choice = -1;
    sscanf(input, "%d", &choice);
    if(choice < 0 || choice > index)
    {
      printf("Not within bounds\n");
      quit(s);
    }
    printf("Within bounds\n");     
    (menu + choice)->fun(s);
    printf("DONE.\n\n");
  }
  return 0;
}