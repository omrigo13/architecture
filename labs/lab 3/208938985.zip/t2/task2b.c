#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int offsetsize = 18;
int zerochar = '0';
int sigSize = 16;
int fileSize = 128;
int buffer10K = 10000;

typedef struct virus {
    unsigned short SigSize;
    char virusName[16];
    unsigned char* sig;
} virus;

typedef struct link link;

struct link {
    link *nextVirus;
    virus *vir;
};

struct fun_desc {
  char *name;
  char (*fun)(char);
};

link* listOfViruses = NULL;

virus* readVirus(FILE* file)
{
/* gets a file pointer and return a virus* represents the next virus in the file*/
    unsigned char size[2];
    unsigned short newSigSize;
    virus* new_virus = NULL;
    if (fread(size, 1, 2, file) != 0)
    {
        newSigSize = *(unsigned short *)size;
        new_virus = (virus *)malloc(sizeof(virus));
        new_virus->SigSize = newSigSize;
        fread(new_virus->virusName, 1, sigSize, file);
        new_virus->sig = malloc(newSigSize);
        fread(new_virus->sig, 1, new_virus->SigSize, file);
    }
    return new_virus;
}

void printHex(char* buffer, int length, FILE* output) 
{
    for(int i = 0; i < length; i++)
        fprintf(output, "%02hhX ", &buffer[i]);
    fprintf(output, "\n");
}

void printVirus(virus* virus, FILE* output)
{
/* gets a virus and a pointer to an output file. prints the virus to the given output
   virus name in ascii
   virus signature length in decimal
   virus signature in hexadecimal
*/
    fprintf(output, "Virus name: %s\nVirus size: %d\nsignature:\n", virus->virusName, virus->SigSize);
    printHex(&virus->sig, virus->SigSize, output);
    fprintf(output, "\n");
}

void list_print(link* virus_list, FILE* file)
{
/* Print the data of every link in list to the given stream. Each item followed by a newline character. */
    while(virus_list != NULL)
    {
        printVirus(virus_list->vir, file);
        virus_list = virus_list->nextVirus;
    }   
}

link* list_append(link* virus_list, virus* data)
{
    link* curr = virus_list;
    if(virus_list == NULL)
    {
        virus_list = (link*)calloc(sizeof(link),1);
        virus_list->vir = data;
        virus_list->nextVirus = NULL;
        return virus_list;
    }
    while(curr->nextVirus!=NULL)
        curr=curr->nextVirus;
    curr->nextVirus = (link*)calloc(sizeof(link),1);
    curr->nextVirus->vir = data;
    curr->nextVirus->nextVirus = NULL;
    return virus_list;
} 

void list_free(link *virus_list)
{
/* Free the memory allocated by the list. */
    while(virus_list != NULL)
    {
        link* FreeViruses = virus_list;
        virus_list = virus_list->nextVirus;
        free(FreeViruses->vir->sig);
        free(FreeViruses->vir);
        free(FreeViruses);
    }
}    

void detect_virus(char *buffer, unsigned int size, link *virus_list)
{
    while(virus_list != NULL)
    {
        for(int i = 0; i < size; i++)
        {
            if(i + virus_list->vir->SigSize <= size)
                if(memcmp(&buffer[i], &virus_list->vir->sig, virus_list->vir->SigSize) == 0)
                {
                    printf("location: %02X\nVirus name: %s\nVirus size: %d\n\n", i, virus_list->vir->virusName, virus_list->vir->SigSize);
                    break;
                }   
        }
        virus_list = virus_list->nextVirus;
    }
}

void detect()
{
    char buffer[buffer10K];
    char filename[fileSize];
    int size = 0;
    FILE* file = NULL;

    printf("please enter a suspected file name: ");
    fgets(filename, fileSize, stdin);
    sscanf(filename, "%s", filename);
    file = fopen(filename, "r");
    if(size > sizeof(buffer))
    {
        printf("too big file");
        exit(-1);
    }
    fseek(file, 0 , SEEK_END);
    size = ftell(file);
    fseek(file, 0 , SEEK_SET);
    fread(buffer, 1, size, file);
    detect_virus(buffer, size, listOfViruses);
    fclose(file);
}

//starting at 507 and size 12 for remove I am virus1!
void kill_virus(char *fileName, int signitureOffset, int signitureSize)
{
/* fixes a virus by getting starting point and size of virus */
    char nop = 0x90;
    FILE* file = NULL;
    file = fopen(fileName, "r+");
    if(file == NULL)
    {
        puts("can't read from a file");
        exit(-1);
    }
    fseek(file, signitureOffset, SEEK_SET);
    for(int i = 0; i < signitureSize; i++)
    {
        fwrite(&nop, 1, 1, file);
        fseek(file, signitureOffset + i + 1, SEEK_SET);
    }
    fclose(file);
}

void fix_file()
{
    char filename[fileSize];
    char buffer[fileSize];
    int offset = 0;
    int size = 0;
    printf("please enter a suspected file's name: ");
    fgets(filename, fileSize, stdin);
    sscanf(filename, "%s", filename);
    printf("please enter the virus's starting byte: ");
    fgets(buffer, fileSize, stdin);
    sscanf(buffer, "%d", &offset);
    printf("please enter the virus's signature size: ");
    fgets(buffer, fileSize, stdin);
    sscanf(buffer, "%d", &size);
    kill_virus(filename, offset, size);
}

void quit()
{
    list_free(listOfViruses);
    exit(0);
}

void loadSigs()
{
    char fileName[fileSize];
    FILE* file = NULL;
    virus* vir = NULL;

    printf("Please enter a signatures file name: ");
    fgets(fileName, fileSize, stdin);
    sscanf(fileName, "%s", fileName);
    file = fopen(fileName, "r");
    if (file != NULL){
        while((vir = readVirus(file)) != NULL){
            listOfViruses = list_append(listOfViruses, vir);
        }
    }
    fclose(file);
}

void printSigs()
{
    list_print(listOfViruses, stdout);
}


struct fun_desc menu[] = { { "Load signatures", loadSigs }, { "Print signatures", printSigs }, {"Detect viruses", detect} , {"Fix file", fix_file}, { "Quit", quit }, { NULL, NULL } };

int MenuSize()
{
  int size = 0;
  while(menu[size].name != NULL)
    size++;
  return size;
}

void MenuDisplay()
{
  int i = 0;
  printf("Please choose a function:\n");
  while(menu[i].name != NULL)
  {
    printf("%d) %s\n", (i+1), menu[i].name);
    i++;
  }
  printf("Option: ");
}

int main(int argc, char **argv) {
    int choice;
    MenuDisplay();
    choice = fgetc(stdin) - zerochar - 1;
    // virus* new_virus = (virus *)malloc(12 + sizeof(char[16]) + sizeof(virus));
    // new_virus->SigSize = 12;
    // char* word = "I am virus1!";
    // strcpy(new_virus->virusName, word);
    // listOfViruses = (link*)calloc(sizeof(link), 1);
    // listOfViruses->vir = new_virus;
    // listOfViruses->nextVirus = NULL;
    while(choice >= 0 && choice < MenuSize())
    {
        fgetc(stdin);
        printf("Within bounds\n");
        (menu + choice)->fun(listOfViruses);
        printf("DONE.\n\n");
        MenuDisplay();
        choice = fgetc(stdin) - zerochar - 1;
    }
    printf("Not within bounds");
    return 0;
}