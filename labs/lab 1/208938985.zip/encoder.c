#include <stdio.h>
#include <string.h>

const int asciichar = 'a' - 'A';
const int aschiinum = '1' - 1;

int main(int argc, char **argv) {
    FILE* in;
    FILE* out = stdout;
    char ch, c;
    char* encode;
    int debug = 0, encoder = 0, pos, index = 2, fileout = 0, filein = 0;
    for(int i = 1; i < argc; i++)
    {
        if(strcmp(argv[i],"-D") == 0)
            debug = 1;
        if(strncmp(argv[i], "+e", 2) == 0)
        {
            encoder = 1;
            encode = argv[i];
        }
        if(strncmp(argv[i], "-e", 2) == 0)
        {
            encoder = -1;
            encode = argv[i];
        }
        if(strncmp(argv[i], "-o", 2) == 0)
        {
            fileout = 1;
            out = fopen(argv[i] + 2, "w");
            if(out == NULL)
            {
                puts("can't write to file");
                return -1;
            }
        }
        if(strncmp(argv[i], "-i", 2) == 0)
        {
            filein = 1;
            in = fopen(argv[i] + 2, "r");
            if(in == NULL)
            {
                puts("no such input file");
                return -1;
            }
        }
    }
    if(debug)
            for(int i = 1; i < argc; i++)
                fprintf(stderr, "%s\n", argv[i]);
    if(!filein)
        in = stdin;
    ch = fgetc(in);
    pos = encode[index] - aschiinum;
    while(ch != EOF)
    {
        if(encoder != 0)
        {
            c = ch + encoder*pos;
            if(ch == '\n')
            {
                index = 2;
                pos = encode[index] - aschiinum;
            }
            else if(pos == encode[strlen(encode) - 1] - aschiinum)
            {
                index = 2;
                pos = encode[index] - aschiinum;
            }
            else
                pos = encode[++index] - aschiinum;
        }
        else if(ch >= 'a' && ch <= 'z')
            c = ch - asciichar;
        else
            c = ch;
        if(debug)
        {
            if(ch == '\n')
                fprintf(stderr, "\n");
            else
                fprintf(stderr, "%d\t%d\n", ch, c);
        }
        if(!encoder || (encoder != 0 && ch != '\n'))
        {
            if(fileout)
                fputc(c, out);
            else
            printf("%c", c);
        }
        if(encoder != 0 && ch == '\n')
        {
            if(fileout)
                fputc('\n', out);
            else
            printf("\n");
        }
        ch = fgetc(in);
    }
    if(filein)
        printf("\n");
    fclose (out);
    fclose (in);
    return 0;
}